<?php

echo $this->extend('layout/main'); //link na layout
echo $this->section('content');



echo form_open('loginSend');
?>
<div class="alert alert-danger"><?= $error; ?></div>

<div class="form-floating mb-3 mt-3">
  <input type="text" class="form-control" id="username" placeholder="Vložte uživatelské jméno" name="uzjmeno">
  <label for="username">Vložte uživatelské jméno</label>
</div>

<div class="form-floating mb-3 mt-3">
  <input type="text" class="form-control" id="name" placeholder="Vložte jméno" name="jmeno">
  <label for="jmeno">Jméno</label>
</div>


<div class="form-floating mb-3 mt-3">
  <input type="text" class="form-control" id="surname" placeholder="Vložte příjmení" name="prijmeni">
  <label for="prijmeni">Příjmení</label>
</div>

<div class="form-floating mb-3 mt-3">
  <input type="text" class="form-control" id="email" placeholder="Vložte email" name="email">
  <label for="email">Vložte email</label>
</div>

<div class="form-floating mt-3 mb-3">
  <input type="text" class="form-control" id="pswd" placeholder="Vložte heslo" name="pswd">
  <label for="pswd">Vložte heslo</label>
</div>

<div class="form-floating mt-3 mb-3">
  <input type="text" class="form-control" id="pswd2" placeholder="Vložte heslo podruhé" name="pswd2">
  <label for="pswd2">Vložte heslo podruhé</label>
</div>
<button type="submit" class="btn btn-primary">Submit</button>
<?php
echo form_close();

echo $this->endSection();