<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use \IonAuth\Libraries\IonAuth;
use Psr\Log\LoggerInterface;

class Auth extends BaseController
{
    var $ionAuth;

    function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)

    {
        parent::initController($request, $response, $logger);
        $this->ionAuth = new IonAuth();
    }

    public function login(){
        if(isset($this->session)){
            $data['error'] = $this->session->error;
        } else{
            $data['error'] = "";
        }
        echo view('loginForm', $data);
    }
    public function loginSend(){
        $name = $this->request->getPost('email');
        $password = $this->request->getPost('pswd');

       $logged = $this->ionAuth->login($name, $password);

       if($logged){
        return redirect()->to('admin/dashboard');
    
       }else{
        $this->session->setFlashdata('error', 'Zadali jste špatné přihlašovací jméno nebo heslo');
        return redirect()->to('login');
       }
    }
}